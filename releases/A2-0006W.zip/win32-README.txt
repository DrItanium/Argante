This archive contains binaries from A2 0.006 compiled
for Win32 x86. This is intended to be supplementary
to the source archive and does not include the
example files and documentation to be found there.

It's all compiled in Borland C++ 4.5 for ideological
purity. :)

All of this stuff is offered under the terms of the
GNU Library General Public License version 2, which
means:

This program is distributed in the hope that it will
be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.

So now you know.

Name				Description
-----------------------------------------------------
a2.exe				A2 interpreter / VM
nagt.exe			compiler for .agts
imgdump.exe			.img disassembler

conf/scripts/argboot.scr	boot script
control.img			Control benchmark
conf/bench.HAC			Access Control file
				for control.img

cw3215.dll			Run-time DLL
-----------------------------------------------------
Caveats:

This is only v0.006, and so what you are playing with
now is only 1/200th of what is planned. The next
release will definitely have a much sexier demo app.

Equally, if you find a bug, EMAIL ME! with details
on how to reproduce it, and then there will be no
bugs in the next version. Just like this one.

The multithreading is not yet Win32ized, so you'll
have to wait to be able to run multiple images,
change HAC rules on the fly, or use the console
while a program is running.

Cify isn't much use without a C compiler, and
LACRETNI hasn't been ported yet.

James Kehl <ecks@optusnet.com.au>
