This archive contains binaries from A2 0.009 compiled
for Win32 x86. This is intended to be supplementary
to the source archive and does not include the
example files and documentation to be found there.

It's all compiled in Borland C++ 4.5 for ideological
purity. :)

All of this stuff is offered under the terms of the
GNU (Library) General Public License version 2, which
means:

This program is distributed in the hope that it will
be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.

So now you know.

Name				Description
-----------------------------------------------------
a2.exe				A2 interpreter / VM
nagt.exe			compiler for .agts
lac.exe				compiler for .lacs
imgdump.exe			.img disassembler
imgstrip.exe			.img symbol stripper
vconsole.exe			virtual console tool

zilch.img			Zilch - the game
control.img			Control benchmark

conf/scripts/argboot.scr	boot script
conf/bench.HAC			Access Control file
				for control.img

cw3215.dll			Run-time DLL
-----------------------------------------------------
Caveats:

Being v0.009, this is still only a 111th of what is
planned... although this release finally adds a
real, interactive "demo app"!

In future, "vconsole" will be used to interact with
text-driven applications. It is also based on the
communications library that Agents will use. You can
currently use it as a basic netcat.

Thanks to the brain-dead design of the Win32 API,
vconsole is forced to use low-level console commands
to read keyboard input without blocking. This makes
it impossible to redirect stdin/out. 

If you find a bug, EMAIL ME! with details on how to
reproduce it, and then there will be no bugs in the
next version. Just like this one.

The multithreading is not yet Win32ized, so you'll
have to wait to be able to run multiple images,
change HAC rules on the fly, or use the manager
console while a program is running.

Cify isn't much use without a C compiler; and if you
have a C compiler why did you download these binaries?

James Kehl <ecks@optusnet.com.au>
